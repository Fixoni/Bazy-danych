<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>wypisywanie z bazy danych chapter 2</title>
</head>
<body>
<h1>skrypt 1</h1>
<?php
$connect = mysqli_connect('localhost','root','','kurs') or die ('Błąd połaczenia');
$zapytanie1 ="select nazwisko,etat,placa_pod from pracownicy order by placa_pod ASC";
$wynik = mysqli_query($connect,$zapytanie1);
echo "<table border=1>";
echo "<tr><th>nazwisko</th>
        <th>etat</th>
        <th>placa_pod</th>
    </tr>";
    while($wiersz = mysqli_fetch_array($wynik)){
    echo "<tr>";
    echo "<td>".$wiersz['nazwisko']."</td>";
    echo "<td>".$wiersz['etat']."</td>";
    echo "<td>".$wiersz['placa_pod']."</td>";
    echo "</tr>";
    }
echo "</table>";

mysqli_close($connect);
?>
<h2>skrypt 2</h2>
        <?php
        $connect = mysqli_connect('localhost','root','','kurs') or die('błąd połączenia');
        $zapytanie2 = "select pracownicy.nazwisko, pracownicy.zatrudniony, zespoly.nazwa, zespoly.adres 
        from pracownicy inner join zespoly on pracownicy.id_zesp=zespoly.id_zesp;";
        $wynik2 = mysqli_query($connect,$zapytanie2);
        echo "<ol>";
        while($wiersz2 = mysqli_fetch_array($wynik2)){
            echo "<li>";
                echo $wiersz2[0]." ";
                echo $wiersz2[1]." ";
                echo $wiersz2[2]." ";
                echo $wiersz2[3]." ";
            echo "</li>";
        }
        echo "</ol>";

                mysqli_close($connect);
        ?>
<h3>skrypt 3</h3>
        <?php
        $connect = mysqli_connect('localhost','root','','kurs') or die('błąd połączenia');
        $zapytanie3 = "select pracownicy.nazwisko, pracownicy.zatrudniony, zespoly.nazwa, zespoly.adres 
        from pracownicy, zespoly 
        where zespoly.nazwa='administracja' and pracownicy.id_zesp=zespoly.id_zesp;";
        $wynik3 = mysqli_query($connect,$zapytanie3);
        echo "<ol>";
        while($wiersz3 = mysqli_fetch_array($wynik3)){
                echo "<li>".$wiersz3[0]." ";
                echo $wiersz3[1]." ";
                echo $wiersz3[2]." ";
                echo $wiersz3[3]."</li>";
        }
        echo "</ol>";

                mysqli_close($connect);
        
        
        
        ?>
</body>
</html>