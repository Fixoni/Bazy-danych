<?php
 
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pierwsze spotkanie z PHP i MYSQL</title>
</head>
<body>
<?php
//połączenie z bazą danych
$polaczenie=mysqli_connect('localhost','root','','kurs')
or die("błąd połączenia");
 
//zapytanie : wypisuje dane wszystkich pracowników z tabeli pracownicy
$zapytanie="select * from pracownicy;";
$zapytanie2="select id_prac, nazwisko, etat, zatrudniony from pracownicy; ";
 
//podpięcie zapytania do bazy danych
$wynik1=mysqli_query($polaczenie,$zapytanie);
$wynik2=mysqli_query($polaczenie,$zapytanie2);
$wynik2=mysqli_query($polaczenie,"select nazwisko from pracownicy;");
//wypisanie wyników zapytania 
while($wiersz=mysqli_fetch_assoc($wynik1)){
    echo $wiersz['ID_PRAC'];
    echo " ";
    echo $wiersz['NAZWISKO'];
    echo " ";
    echo $wiersz["ETAT"];
    echo " ";
    echo $wiersz["ZATRUDNIONY"];
    echo " ";
    echo "<br/>";
}
echo "<br/>zapytanie nr 2<br/>";
$wynik2=mysqli_query($polaczenie,$zapytanie2);
echo "<ul>";//początek listy nienumerowanej
while($wiersz2=mysqli_fetch_array($wynik2)){
    echo "<li>".$wiersz2[0]." ";
    echo "<li>".$wiersz2[1]." ";
    echo "<li>".$wiersz2[2]." ";
    echo "<li>".$wiersz2[3]."</li>";
}
echo "</ul>";//koniec listy nienumerowanej
 
//zapytanie 4: wypisze ile rekordów w bazie danych jest na etacie profesor.
$zapytanie4='select * from pracownicy where etat="PROFESOR";';
$wynik4=mysqli_query($polaczenie,$zapytanie4);
$ileProfesorow=mysqli_num_rows($wynik4);

echo "Profesorów w bazie danych jest: " .$ileProfesorow;
 
 
//zamknięcie dostępu do bazy danych
mysqli_close($polaczenie);
?>
<br/>
<?php
 
?>
</body>
</html>