<?php
$login = $_POST['login'];
$pass= $_POST['pass'];
if($login=='admin' && $pass=='1234'){
    header('location:hotel.html');
}else{
    echo 'Błędne hasło';
}

?>
 