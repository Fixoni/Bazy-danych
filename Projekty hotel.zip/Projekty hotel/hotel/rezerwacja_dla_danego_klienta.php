<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodawanie rezerwacji</title>
</head>
<body>

</body>
    <?php
 
 $connect = mysqli_connect('localhost','root','','hotel') or die('błąd połączenia');
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $sql = "SELECT id_klienta, imie, nazwisko FROM hotele_klienci";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        
        echo '<form method="POST" action="dodaj_rezerwacje.php">';
        echo '<label>Wybierz klienta:</label>';
        echo '<select name="idKlienta">';
        while($row = $result->fetch_assoc()) {
            echo '<option value="' . $row["id_klienta"] . '">' . $row["imie"] . ' ' . $row["nazwisko"] . '</option>';
        }
        echo '</select>';
        echo '<br>';
        echo '<label>Podaj datę rozpoczęcia (RRRR-MM-DD):</label>';
        echo '<input type="text" name="dataRozpoczecia">';
        echo '<br>';
        echo '<label>Podaj datę zakończenia (RRRR-MM-DD):</label>';
        echo '<input type="text" name="dataZakonczenia">';
        echo '<br>';
        echo '<label>Podaj ID pokoju:</label>';
        echo '<input type="number" name="idPokoju">';
        echo '<br>';
        echo '<input type="submit" value="Dodaj rezerwację">';
        echo '</form>';
    } else {
        echo "Nie znaleziono klientów.";
    }
    
   
    $conn->close();
    ?>
</html>