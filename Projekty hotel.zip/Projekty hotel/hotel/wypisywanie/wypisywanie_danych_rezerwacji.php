<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>wypisywanie z bazy danych</title>
</head>
<body>


        <?php
        $connect = mysqli_connect('localhost','root','','hotel') or die('błąd połączenia');
        $zapytanie1 = "select * from hotele_rezerwacje";
        $wynik = mysqli_query($connect,$zapytanie1);

     echo "<table border=1>";
echo "<tr><th>id rezerwacji</th>
        <th>id klienta</th>
        <th>poczatek rezerwacji</th>
        <th>koniec rezerwacji</th>
        <th>id pokoju</th>
        <th>id parkingu</th>
        <th>zrealizowane</th>
        
    </tr>";
    while($wiersz = mysqli_fetch_array($wynik)){
    echo "<tr>";
    echo "<td>".$wiersz['id_rezerwacji']."</td>";
    echo "<td>".$wiersz['id_klient']."</td>";
    echo "<td>".$wiersz['data_start_rezerwacji']."</td>";
    echo "<td>".$wiersz['data_koniec_rezerwacji']."</td>";
    echo "<td>".$wiersz['id_pokoju']."</td>";
    echo "<td>".$wiersz['id_parking']."</td>";
    echo "<td>".$wiersz['zrealizowane']."</td>";
    
    echo "</tr>";
    }
echo "</table>";

mysqli_close($connect);
?>
</body>
</html>