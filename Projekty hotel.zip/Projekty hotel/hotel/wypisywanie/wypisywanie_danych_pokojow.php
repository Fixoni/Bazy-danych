<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>wypisywanie z bazy danych</title>
</head>
<body>


        <?php
        $connect = mysqli_connect('localhost','root','','hotel') or die('błąd połączenia');
        $zapytanie1 = "select * from hotele_pokoje";
        $wynik = mysqli_query($connect,$zapytanie1);

     echo "<table border=1>";
echo "<tr><th>id pokoju</th>
        <th>id hotelu</th>
        <th>nr pokoju</th>
        <th>pietro</th>
        <th>ilosc ludzi w pokoju</th>
        
    </tr>";
    while($wiersz = mysqli_fetch_array($wynik)){
    echo "<tr>";
    echo "<td>".$wiersz['id_pokoju']."</td>";
    echo "<td>".$wiersz['id_hotel']."</td>";
    echo "<td>".$wiersz['nr_pokoju']."</td>";
    echo "<td>".$wiersz['pietro']."</td>";
    echo "<td>".$wiersz['ludzie']."</td>";
   
    echo "</tr>";
    }
echo "</table>";

mysqli_close($connect);
?>
</body>
</html>