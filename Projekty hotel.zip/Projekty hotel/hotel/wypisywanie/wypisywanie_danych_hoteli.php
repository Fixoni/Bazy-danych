<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>wypisywanie z bazy danych</title>
</head>
<body>


        <?php
        $connect = mysqli_connect('localhost','root','','hotel') or die('błąd połączenia');
        $zapytanie1 = "select * from hotele_hotele";
        $wynik = mysqli_query($connect,$zapytanie1);

     echo "<table border=1>";
echo "<tr><th>id hotelu</th>
        <th>nazwa</th>
        <th>id kraju</th>
        <th>id miasta</th>
        <th>adres</th>
        <th>gwiazdki</th>
        <th>telefon</th>
        <th>email</th>
        <th>www</th>
    </tr>";
    while($wiersz = mysqli_fetch_array($wynik)){
    echo "<tr>";
    echo "<td>".$wiersz['id_hotel']."</td>";
    echo "<td>".$wiersz['nazwa']."</td>";
    echo "<td>".$wiersz['id_kraj']."</td>";
    echo "<td>".$wiersz['id_miasto']."</td>";
    echo "<td>".$wiersz['adres']."</td>";
    echo "<td>".$wiersz['gwiazdki']."</td>";
    echo "<td>".$wiersz['telefon']."</td>";
    echo "<td>".$wiersz['email']."</td>";
    echo "<td>".$wiersz['www']."</td>";
    echo "</tr>";
    }
echo "</table>";

mysqli_close($connect);
?>
</body>
</html>