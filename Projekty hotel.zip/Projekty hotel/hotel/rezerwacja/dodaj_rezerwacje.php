<!DOCTYPE html>
<html>
<head>
	<title>Dodaj rezerwację</title>
    <link rel="stylesheet" type="text/css" href="rezerwacja.css">
</head>
<body>
	<h2>Dodaj rezerwację</h2>
    <form action="dodaj_rezerwacje.php" method="post">
        <label for="imie">Imię:</label>
        <input type="text" id="imie" name="imie"><br>
      
        <label for="nazwisko">Nazwisko:</label>
        <input type="text" id="nazwisko" name="nazwisko"><br>
      
        <label for="telefon">Telefon:</label>
        <input type="tel" id="telefon" name="telefon"><br>
      
        <label for="email">Email:</label>
        <input type="email" id="email" name="email"><br>
      
        <label for="checkin">Data zameldowania:</label>
        <input type="date" id="checkin" name="checkin"><br>
      
        <label for="checkout">Data wymeldowania:</label>
        <input type="date" id="checkout" name="checkout"><br>
      
        <label for="id_klienta">ID klienta:</label>
        <select id="id_klienta" name="id_klienta">
        <?php
           $connect = mysqli_connect('localhost','root','','hotel') or die('błąd połączenia');
            // Fetch the data from the table
            $query = "SELECT id_klienta FROM hotele_klienci";
            $result = mysqli_query($conn, $query);

            // Loop through the data and display as options
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<option value='" . $row['id_klienta'] . "'>" . $row['id_klienta'] . "</option>";
            }

            // Close the database connection
            mysqli_close($conn);
        ?>
        </select><br>
      
        <label for="pokoj">Numer pokoju:</label>
        <input type="text" id="pokoj" name="pokoj"><br>
      
        <input type="submit" value="Zarezerwuj">
    </form>
</body>
</html>