<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>wypisywanie danych klientów - rezerwacja w danym terminie</title>
</head>
<body>


<form method="POST" action="klienci_dany_termin.php">
<p>Podaj termin rozpoczęcia rezerwacji</p>
<input type="date" name="poczatek" required/>
<br/>
<p>Podaj termin zakończenia rezerwacji</p>
<input type="date" name="koniec" required/>
<br/>
<input type="submit" value="Znajdź"/>
<input type="reset" />

</form>
        <?php
        $connect = mysqli_connect('localhost','root','','hotel') or die('błąd połączenia');
        $poczatek=$_POST['poczatek'];
        $koniec=$_POST['koniec'];
        $zapytanie1 = "select * from hotele_rezerwacji where data_start_rezerwacji='$poczatek' and data_koniec_rezerwacji='$koniec' ";
        $wynik = mysqli_query($connect,$zapytanie1);

    echo "<table border=1>";
    echo "<tr><th>id klienta</th>
        <th>imie</th>
        <th>nazwisko</th>
        <th>id kraju</th>
        <th>id miasto</th>
        <th>adres</th>
        <th>liczba osób w pokoju</th>
        <th>nr dokumentacji</th>
    </tr>";
    while($wiersz = mysqli_fetch_array($wynik)){
    echo "<tr>";
    echo "<td>".$wiersz['id_klient']."</td>";
    echo "<td>".$wiersz['imie']."</td>";
    echo "<td>".$wiersz['nazwisko']."</td>";
    echo "<td>".$wiersz['id_kraju']."</td>";
    echo "<td>".$wiersz['id_miasto']."</td>";
    echo "<td>".$wiersz['adres']."</td>";
    echo "<td>".$wiersz['licznik']."</td>";
    echo "<td>".$wiersz['nr_dokumentacji']."</td>";
    echo "</tr>";
    }
echo "</table>";

mysqli_close($connect);
?>
</body>
</html>