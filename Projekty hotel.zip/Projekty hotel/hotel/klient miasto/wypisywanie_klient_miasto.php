<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wypisywanie klientow</title>
    <link href="wypisywanie_klient_miasto.css" rel="stylesheet">
</head>
<body>


        <?php
        $connect = mysqli_connect('localhost','root','','hotel') or die('błąd połączenia');
        $zapytanie1 = "select * from hotele_klienci join hotele_miasta on hotele_klienci.id_miasto=hotele_miasta.id_miasto";
        $wynik = mysqli_query($connect,$zapytanie1);

     echo "<table border=1>";
echo "<tr><th>id klienta</th>
        <th>id imie</th>
        <th>nazwisko</th>
        <th>nazwa miasta</th>
       
        
    </tr>";
    while($wiersz = mysqli_fetch_array($wynik)){
    echo "<tr>";
    echo "<td>".$wiersz['id_klienta']."</td>";
    echo "<td>".$wiersz['imie']."</td>";
    echo "<td>".$wiersz['nazwisko']."</td>";
    echo "<td>".$wiersz['nazwa_miasta']."</td>";
    
    
    echo "</tr>";
    }
echo "</table>";

mysqli_close($connect);
?>
</body>
</html>