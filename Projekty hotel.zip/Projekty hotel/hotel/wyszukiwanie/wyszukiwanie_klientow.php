<?php

$polaczenie=@mysqli_connect('localhost','root','','hotel') or die('Błąd połączenia');

$nazwisko=$_POST['naz'];

$wyszukaj=mysqli_query($polaczenie,"select * from hotele_klienci where nazwisko='$nazwisko';");

$ileNazwisk=mysqli_num_rows($wyszukaj);

echo " osób o nazwisku " .$nazwisko." jest : ".$ileNazwisk;
if($ileNazwisk>0){
echo "<select name='nazwiskoo'>";
while($wiersz=mysqli_fetch_array($wyszukaj)){
echo "<option >"   .$wiersz[0]." " .$wiersz[1]." ".$wiersz[2].
"</option>";

}
echo"</select>";
}
mysqli_close($polaczenie);


?>