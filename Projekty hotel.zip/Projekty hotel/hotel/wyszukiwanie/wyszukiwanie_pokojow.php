<?php

$polaczenie=@mysqli_connect('localhost','root','','hotel') or die('Błąd połączenia');

$numer=$_POST['nr'];//poberanie z formularza

// $pytanie="select * from hotele_klienci where nazwisko='$nazwisko';";
// $wyszukaj=mysqli_query($polaczenie,$pytanie);
$sql=mysqli_query($polaczenie,"select * from hotele_klienci where nazwisko='$numer';");

$ilePokojow=mysqli_num_rows($sql);

echo " Pokojów o numerze " .$numer." jest : ".$ilePokojow;
if($ilePokojow>0){
echo "<select name='nazwiskoo'>";
while($wiersz=mysqli_fetch_array($sql)){
echo "<option >" .$wiersz[1]." ".$wiersz[2]." ".$wiersz[3].
"</option>";

}
echo"</select>";
}
mysqli_close($polaczenie);


?>