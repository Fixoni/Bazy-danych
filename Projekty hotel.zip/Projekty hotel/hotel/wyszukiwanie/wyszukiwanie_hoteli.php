<?php

$polaczenie=@mysqli_connect('localhost','root','','hotel') or die('Błąd połączenia');

$nazwa=$_POST['nazwa'];//poberanie z formularza

// $pytanie="select * from hotele_klienci where nazwisko='$nazwisko';";
// $wyszukaj=mysqli_query($polaczenie,$pytanie);
$wyszukaj=mysqli_query($polaczenie,"select * from hotele_hotele where nazwa='$nazwa';");

$ileHoteli=mysqli_num_rows($wyszukaj);

echo " hoteli o nazwie " .$nazwa." jest : ".$ileHoteli;
if($ileHoteli>0){
echo "<select name='nazwiskoo'>";
while($wiersz=mysqli_fetch_array($wyszukaj)){
echo "<option >" .$wiersz[1]." ".$wiersz[2]." ".$wiersz[3].
"</option>";

}
echo"</select>";
}
mysqli_close($polaczenie);


?>