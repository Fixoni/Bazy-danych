<?php
        $connect = mysqli_connect('localhost','root','','hotel') or die('błąd połączenia');
        $id=$_POST['id'];

        $zapytanie1 = "select * from hotele_rezerwacje where id_rezerwacji=$id";
        $wynik = mysqli_query($connect,$zapytanie1);
       
     echo "<table border=1>";
echo "<tr><th>id rezerwacji</th>
        <th>id klienta</th>
        <th>początek rezerwacji</th>
        <th>koniec rezerwacji</th>
        <th>id pokoju</th>
        <th>id parkingu</th>
        <th>zrealizowane</th>
        
    </tr>";
    while($wiersz = mysqli_fetch_array($wynik)){
    echo "<tr>";
    echo "<td>".$wiersz['id_rezerwacji']."</td>";
    echo "<td>".$wiersz['id_klient']."</td>";
    echo "<td>".$wiersz['data_start_rezerwacji']."</td>";
    echo "<td>".$wiersz['data_koniec_rezerwacji']."</td>";
    echo "<td>".$wiersz['id_pokoju']."</td>";
    echo "<td>".$wiersz['id_parkingu']."</td>";
    echo "<td>".$wiersz['zrealizowane']."</td>";
   
    echo "</tr>";
    }
echo "</table>";
