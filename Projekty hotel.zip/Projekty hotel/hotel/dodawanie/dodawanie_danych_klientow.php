<?php



$imie=$_POST['imie'];
$nazwisko=$_POST['nazwisko'];
$idKraju=$_POST['idKraju'];
$idMiasta=$_POST['idMiasta'];
$adres=$_POST['adres'];
$licznik=$_POST['licznik'];
$dokumentacja=$_POST['dokumentacja'];

$conn=@mysqli_connect('localhost','root','','hotel') or die('Błąd połączenia/bazy');
$sql = "INSERT INTO hotele_klienci(imie,nazwisko,id_kraju,id_miasto,adres,licznik,nr_dokumentacji)
VALUES('$imie','$nazwisko',$idKraju,$idMiasta,'$adres',$licznik,'$dokumentacja')";
$add=mysqli_query($conn,$sql);
if ($add) {
 echo "<p style='background-color: #039be5;
 border: none;
 color: #fff;
 padding: 12px 32px;
 text-decoration: none;
 font-size: 18px;
 border-radius: 30px;
 cursor: pointer;
 transition: background-color 0.2s;
 margin-right: 10px;
 margin-top: 20px;
 width: 95%;
 text-align:center; '>Dodano nowego użytkownika</p>";
  } else {
    echo "<p style='background-color: crimson;
    border: none;
    color: #fff;
    padding: 12px 32px;
    text-decoration: none;
    font-size: 18px;
    border-radius: 30px;
    cursor: pointer;
    transition: background-color 0.2s;
    margin-right: 10px;
    margin-top: 20px;
    width: 95%;
    text-align:center; '>Dodano nowego użytkownika</p>";
  }
  
  mysqli_close($conn);
  ?>