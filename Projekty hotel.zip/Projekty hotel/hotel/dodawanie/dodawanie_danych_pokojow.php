<?php
$conn=new mysqli('localhost','root','','hotel');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

$id_hotel=$_POST['id_hotelu'];
$nr_pokoju=$_POST['nr_pokoju'];
$pietro=$_POST['pietro'];
$ludzie=$_POST['ludzie'];



$sql = "INSERT INTO hotele_pokoje(id_hotel,nr_pokoju,pietro,ludzie)
VALUES ($id_hotel,$nr_pokoju,'$pietro',$ludzie)";

if ($conn->query($sql) === TRUE) {
    echo "Nowa rezerwacja dodana";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
  
  $conn->close();
  ?>