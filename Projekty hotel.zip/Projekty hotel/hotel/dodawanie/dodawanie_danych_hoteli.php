<?php
$conn=new mysqli('localhost','root','','hotel');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

$nazwa=$_POST['nazwa'];
$id_kraj=$_POST['id_kraj'];
$id_miasto=$_POST['id_miasto'];
$adres=$_POST['adres'];
$gwiazdki=$_POST['gwiazdki'];
$telefon=$_POST['telefon'];
$email=$_POST['email'];
$www=$_POST['www'];


$sql = "INSERT INTO hotele_hotele(nazwa,id_kraj,id_miasto,adres,gwiazdki,telefon,email,www)
VALUES ('$nazwa',$id_kraj,$id_miasto,'$adres',$gwiazdki,$telefon,'$email','$www')";

if ($conn->query($sql) === TRUE) {
    echo "Nowa rezerwacja dodana";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
  
  $conn->close();
  ?>