<?php
$conn=new mysqli('localhost','root','','hotel');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

$idKlient=$_POST['idKlient'];
$dataStartRezerwacji=$_POST['dataStartRezerwacji'];
$dataKoniecRezerwacji=$_POST['dataKoniecRezerwacji'];
$idPokoj=$_POST['idPokoj'];
$idParking=$_POST['idParking'];
$zrealizowane=$_POST['zrealizowane'];


$sql = "INSERT INTO hotele_rezerwacje(id_klient,data_start_rezerwacji,data_koniec_rezerwacji,id_pokoju,id_parking,zrealizowane)
VALUES ($idKlient,'$dataStartRezerwacji','$dataKoniecRezerwacji',$idPokoj,$idParking,'$zrealizowane')";

if ($conn->query($sql) === TRUE) {
    echo "Nowa rezerwacja dodana";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
  
  $conn->close();
  ?>