<?php
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>pierwsze spotkanie z php i mysql</title>
</head>
<body>
    <?php
    //polaczenie z baza danych
    $polaczenie=mysqli_connect('localhost','root','','localhost')
    or die('błąd połączenia');

    //zapytanie: wypisuje dane wszystkich pracownikow z tabeli pracownicy
    $zapytanie1='select * from pracownicy;';
    $zapytanie2='select id_prac, nazwisko, etat, zatrudniony from pracownicy;';

    //podpiecie zapytania do bazy danych
    $wynik1=mysqli_query($polaczenie,$zapytanie1);
    $wynik2=mysqli_query($polaczenie,$zapytanie2);
    $wynik3=mysqli_query($polaczenie,'select nazwisko from pracownicy;');

    //wypisanie wynikow zapytania
    while($wiersz1=mysqli_fetch_assoc($wynik1))
    {
        echo $wiersz1['ID_PRAC'];
        echo " ";
        echo $wiersz1['NAZWISKO'];
        echo " ";
        echo $wiersz1['ETAT'];
        echo " ";
        echo $wiersz1['ZATRUDNIONY'];
        echo " ";
        echo "</br>";
    }
echo "<br/>Zapytanie nr 2<br/>";
$wynik2=mysqli_query($polaczenie,$zapytanie2);
echo "<ul>";//początek listy nienumerowanej
while($wiersz2=mysqli_fetch_array($wynik2))
{
    echo "<li>".$wiersz2[0]." ";
    echo $wiersz2[1]." ";
    echo $wiersz2[2]." ";
    echo $wiersz2[3]."</li>";
}
echo "</ul>";//koniec listy nienumerowanej
    //zamkniecie dostepu do bazy danych
    mysqli_close($polaczenie)
    ?>
    </br>
    <?php
        
    ?> 

</body>
