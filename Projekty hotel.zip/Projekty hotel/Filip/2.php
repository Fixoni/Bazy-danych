<?php

?>
<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <title>wypisywanie z baz danych chapter 2</title>
    <meta charset="utf-8"/>

</head>
<body>
    
    <h1>skrypt 1</h1>
    <?php
    $connect=mysqli_connect('localhost','root','','kurs') or die('błąd połączenia');

    $zapytanie1= "select nazwisko,etat,placa_pod from pracownicy order by placa_pod ASC";
    $wynik1= mysqli_query($connect,$zapytanie1);

    echo "<table border=1>";
        echo "<tr>
            <th>nazwisko</th>
            <th>etat</th>
            <th>placa_pod</th>
        </tr>";
            while($wiersz1=mysqli_fetch_array($wynik1)){
                echo "<tr>";
                echo "<td>".$wiersz1[0]."</td>";
                echo "<td>".$wiersz1[1]."</td>";
                echo "<td>".$wiersz1[2]."</td>";
                echo "</tr>";
            }


    echo "</table>";

    mysqli_close($connect);
    ?>

    <h2>skrypt 2</h2>
        <?php
        $connect2=mysqli_connect('localhost','root','','kurs') or die('błąd połączenia');
        $zapytanie2= "select pracownicy.nazwisko, pracownicy.zatrudniony, zespoly.nazwa, zespoly.adres 
        from pracownicy inner join zespoly on pracownicy.id_zesp=zespoly.id_zesp;";
        $wynik2= mysqli_query($connect2,$zapytanie2);
        echo "<ol>";
        while($wiersz2=mysqli_fetch_array($wynik2)){
            echo "<li>";
                echo $wiersz2[0]." ";
                echo $wiersz2[1]." ";
                echo $wiersz2[2]." ";
                echo $wiersz2[3]." ";
            echo "</li>";
        }
        echo "</ol>";

                mysqli_close($connect2);
        ?>
        <h2>skrypt 3</h2>
        <?php
        $connect = mysqli_connect('localhost', 'root', '', 'kurs') or die("błąd");
         $zapytanie3 = "select pracownicy.nazwisko, pracownicy.zatrudniony, zespoly.nazwa, zespoly.adres from pracownicy, zespoly where zespoly.nazwa='administracja' and pracownicy.id_zesp=zespoly.id_zesp;";
        $wynik3 = mysqli_query($connect, $zapytanie3);
        echo "<ol>";
         while($wiersz3=mysqli_fetch_array($wynik3)){
            echo "<li>" . $wiersz3['nazwisko'] . " " . $wiersz3['zatrudniony'] . " " . $wiersz3['nazwa'] . " " . $wiersz3['adres'] . "</li>";
        }
        echo "</ol>";
        mysqli_close($connect);
        ?>
</body>
</html>