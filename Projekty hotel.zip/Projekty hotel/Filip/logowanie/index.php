<!DOCTYPE html>
<html lang="pl">
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="strona.css">
    <head><h1>Logowanie</h1></head>
    <body>
      
    <form class="form" method="POST" action="strona2.php">
    <div><img src="kapibara.jpg" alt="Avatar" class="avatar"></div>
        <div class="container">
       
            <label for="uname"><b>Login</b></label>
    <input type="text" placeholder="Podaj login" name="uname" id="uname" class="uname" required>
    <br></br>
    <label for="psw"><b>Hasło</b></label>
    <input type="password" placeholder="Podaj hasło" id="psw" class="psw" name="psw" required>

    <button type="submit">Login</button>
    <label>
      <input type="checkbox" checked="checked" name="zapamietaj"> Zapamiętaj mnie </label>
      
    </form>
</body>

</html>
