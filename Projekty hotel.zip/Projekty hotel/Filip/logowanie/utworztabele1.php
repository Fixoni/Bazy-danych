<?php
 $polaczenie=mysqli_connect('localhost','root','','januszex')
 or die('błąd połączenia');
 $utworztabele='create table rezerwacje(id_rezerwacji int, id_klient int, data_start_rezerwacji date, data_koniec_rezerwacji date, id_pokoju int, id_parking int, zrealizowane bit, PRIMARY KEY(id_rezerwacji));
 create table kraje(id_kraju int, nazwa_kraju varchar(50), kod_kraju varchar(20), PRIMARY KEY(id_kraju));
 create table klienci(id_klient int, imie varchar(20), nazwisko varchar(40), id_kraju int, id_miasto int, adres varchar(50),licznik int,nr_dokumentacji varchar(40), PRIMARY KEY(id_klient));
 create table pokoje(id_pokoju int, id_hotel int, nr_pokoju int, pietro int, ludzie int, PRIMARY KEY(id_pokoju));
 create table hotele(id_hotel int, nazwa varchar(30), id_kraj int, id_miasto int, adres varchar(50), gwiazdki int, telefon varchar(20), email varchar(50), www varchar(50), PRIMARY KEY(id_hotel));
 create table miasta(id_miasta int, nazwa_miasta varchar(50), kod_miasta varchar(20), PRIMARY KEY(id_miasta));';
 if($utworztabele)
 header('location.strona2.php');
 mysqli_close($polaczenie)
 ?>