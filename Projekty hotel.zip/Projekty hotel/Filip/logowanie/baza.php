<?php
 $polaczenie=mysqli_connect('localhost','root','','januszex')
 or die('błąd połączenia');
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Baza dany Januszex</title>
</head>
<body>

</body>
