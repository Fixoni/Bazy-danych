<?php
 $polaczenie=mysqli_connect('localhost','root','','januszex')
 or die('błąd połączenia');
 
$usuntabele='drop table miasta;
drop table kraje;
drop table klienci;
drop table pokoje;
drop table hotele;
drop table miasta;';
mysqli_close($polaczenie)
?>