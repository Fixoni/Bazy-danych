<?php
$login=$_POST['uname'];
$password=$_POST['psw'];

if($login=="admin" && $password="admin"){
  header('location.strona2.php');
}else{
  header('location.index.php');
}

?>
<!DOCTYPE html>
<html lang="pl">
    <head>
        <title> Baza danych Firma Januszex</title>
        <meta charset="UTF-8"/>
        <link rel="stylesheet" type="text/css" href="arkusz1.css"/>
    </head>
<body>
<div>
<h1>Witaj w Firmie Januszex</h1>
</div>
<div>
<button type="button">Utwórz tabele</button>
<a href="utworztabele1.php">
<button type="button">Usuń tabele</button>
<a href="usuntabele2.php">
</div>
<div>
<button type="button">Click Me!</button>
<button type="button">Click Me!</button>
</div>



<?php
 $polaczenie=mysqli_connect('localhost','root','','januszex')
 or die('błąd połączenia');
 
$usuntabele='drop table miasta;
drop table kraje;
drop table klienci;
drop table pokoje;
drop table hotele;
drop table miasta;';
mysqli_close($polaczenie)
?>


</body>
</html>