<?php
//include('polaczenie.php');
//require('polaczenie.php');
$polaczenie=@mysqli_connect('localhost','root','','kurs') or die("bład");
$nazwisko=$_POST['naz'];
$pytanie="select * from pracownicy where nazwisko='$nazwisko';";
$wyszukaj=mysqli_query($polaczenie,$pytanie);
$ilenazwisk=mysqli_num_rows($wyszukaj);
echo "osób o naziwsku ".$nazwisko." jest: ".$ilenazwisk;
echo "<select name='nazwisko'>";
    while($wiersz=mysqli_fetch_array($wyszukaj)){
        echo "<option >".$wiersz[1]." ".$wiersz2[2]." ".$wiersz[3]."</option>";
    }
    echo "</select>";
mysqli_close($polaczenie);
?>