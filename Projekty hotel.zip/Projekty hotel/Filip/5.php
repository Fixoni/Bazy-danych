
<?php
//include('polaczenie.php');
//require('polaczenie.php');
$nazwisko=$_POST['naz'];
$etat=$_POST['eta'];

$polaczenie=@mysqli_connect('localhost','root','','kurs') or die("bład");
$zapytanie="delete from pracownicy where nazwisko='$nazwisko' && etat='$etat';";
$usunnazwisko=mysqli_query($polaczenie,$zapytanie);
if($usunnazwisko){
        echo "usunieto ".$nazwisko." z bazy pracownikow. witaj w firmei";}




?>