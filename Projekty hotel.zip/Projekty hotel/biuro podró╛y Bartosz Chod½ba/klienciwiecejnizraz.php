<?php


$conn = mysqli_connect('localhost','root','','hotele') or die('błąd połączenia');

$sql = "SELECT klienci. * FROM rezerwacje JOIN klienci ON rezerwacje.id_klient = klienci.id_klient WHERE rezerwacje.zrealizowane = 1 HAVING COUNT(zrealizowane) > 1";


$result = mysqli_query($conn, $sql);
if (!$result) {
    die("Błąd zapytania: " . mysqli_error($conn));
}

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "ID klienta: " . $row["id_klient"] . " - Imię i nazwisko: " . $row["imie"] . " " . $row["nazwisko"] . "<br>";
    }
} else {
    echo "Brak wyników.";
}


mysqli_close($conn);

?>