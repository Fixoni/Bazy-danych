<?php

$conn=@mysqli_connect('localhost','root','','hotele') or die('Błąd połączenia');
if(!isset($numer)){
    $numer=$_POST['nr']; 
}


$zapytanie="select * from pokoje where ludzie=$numer";
$sql = mysqli_query($conn,$zapytanie);
$ileludzi=mysqli_num_rows($sql);
if($ileludzi = 1){
   
    echo "<p> W pokoju o numerze " .$numer." jest ".$ileludzi. " osoba</p>";
}

else if($ileludzi>1){
    echo " W pokoju o numerze " .$numer." jest ".$ileludzi. " osób";
}

mysqli_close($conn);  


?>
