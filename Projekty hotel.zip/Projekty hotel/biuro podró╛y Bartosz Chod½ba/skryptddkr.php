<?php
 $conn = mysqli_connect('localhost','root','','hotele') or die('błąd połączenia');

$idKlient=$_POST['id_klient'];

$dataStartRezerwacji=$_POST['checkin'];
$dataKoniecRezerwacji=$_POST['checkout'];
$idPokoj=$_POST['pokoj'];
$idParking=$_POST['number'];
$zrealizowane=$_POST['zrealizowane'];

$sql = "INSERT INTO rezerwacje(id_klient,data_start_rezerwacji,data_koniec_rezerwacji,id_pokoju,id_parking,zrealizowane)
VALUES ($idKlient,'$dataStartRezerwacji','$dataKoniecRezerwacji',$idPokoj,$idParking,'$zrealizowane')";

$add=mysqli_query($conn,$sql);
if ($add) {
 echo "<p>Dodano nową rezerwację</p>";
  } else {
    echo "<p> Nie dodano nowej rezerwacji</p>";
  }

  
  
  mysqli_close($conn);
  ?>