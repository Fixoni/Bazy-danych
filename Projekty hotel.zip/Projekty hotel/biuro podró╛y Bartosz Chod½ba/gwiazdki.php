<?php
 $conn = mysqli_connect('localhost','root','','hotele') or die('błąd połączenia');

$gwiazdki = $_POST["gwiazdki"];


$sql = "SELECT COUNT(*) as ilosc_klientow FROM hotele WHERE gwiazdki = $gwiazdki";


$result = $conn->query($sql);


if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		echo "<p>Ilość klientów w hotelach $gwiazdki-gwiazdkowych: " . $row["ilosc_klientow"] . "</p>";
	}
} else {
	echo "Brak wyników.";
}


$conn->close();
?>