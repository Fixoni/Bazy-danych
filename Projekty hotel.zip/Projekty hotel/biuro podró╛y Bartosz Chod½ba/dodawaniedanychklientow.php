<?php


$imie=$_POST['imie'];
$nazwisko=$_POST['nazwisko'];
$idkraj=$_POST['idkraj'];
$idmiasto=$_POST['idmiasto'];
$adres=$_POST['adres'];
$licznik=$_POST['licznik'];
$dokumentacja=$_POST['dokumentacja'];

$conn=@mysqli_connect('localhost','root','','hotele') or die('Błąd połączenia/bazy');
$sql = "INSERT INTO klienci(imie,nazwisko,id_kraju,id_miasto,adres,licznik,nr_dokumentacji)
VALUES('$imie','$nazwisko','$idkraj','$idmiasto','$adres','$licznik','$dokumentacja')";
$add=mysqli_query($conn,$sql);
if ($add) {
    echo "Dodano nowego użytkownika";
  } else {
    echo "Nie dodano";
  }
  
  mysqli_close($conn);
  ?>