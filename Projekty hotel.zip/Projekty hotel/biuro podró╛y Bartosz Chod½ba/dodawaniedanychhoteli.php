<?php


$nazwa=$_POST['nazwa'];
$idkraj=$_POST['idkraj'];
$idmiasto=$_POST['idmiasto'];
$adres=$_POST['adres'];
$gwiazdki=$_POST['gwiazdki'];
$telefon=$_POST['telefon'];
$email=$_POST['email'];
$www=$_POST['www'];

$conn=@mysqli_connect('localhost','root','','hotele') or die('Błąd połączenia/bazy');
$sql = "INSERT INTO hotele(nazwa,id_kraj,id_miasto,adres,gwiazdki,telefon,email,www)
VALUES('$nazwa','$idkraj','$idmiasto','$adres','$gwiazdki','$telefon','$email','$www')";
$add=mysqli_query($conn,$sql);
if ($add) {
    echo "Dodano dane hotelu";
  } else {
    echo "Nie dodano";
  }
  
  mysqli_close($conn);
  ?>