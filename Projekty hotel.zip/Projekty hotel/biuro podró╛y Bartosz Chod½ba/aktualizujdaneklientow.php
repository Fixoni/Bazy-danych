<?php
// Połączenie z bazą danych
$connect=mysqli_connect('localhost','root','','hotele')
or die("błąd połączenia");


// Pobranie danych z formularza
$id_klient = $_POST["idklient"];
$imie = $_POST["imie"];
$nazwisko = $_POST["nazwisko"];
$id_kraju = $_POST["idkraju"];
$id_miasto = $_POST["idmiasto"];
$adres = $_POST["adres"];
$licznik = $_POST["licznik"];
$nr_dokumentacji = $_POST["nrdokumentacji"];

// Aktualizacja danych klienta
$sql = "UPDATE klienci SET id_klient='$id_klient', imie='$imie',  nazwisko='$nazwisko' ,  id_kraju='$id_kraju',     id_miasto='$id_miasto'  , adres='$adres',     licznik='$licznik', nr_dokumentacji='nrdokumentacji' WHERE id_klient='$id_klient'";

$upd=mysqli_query($connect,$sql);
    if($upd){
        echo "Zaktualizowano dane";
    }

    mysqli_close($connect);
?>