<?php
$conn=new mysqli('localhost','root','','hotele');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
$idrezerwacji=$_POST['idrezerwacji'];
$idklienta=$_POST['idklienta'];
$datastartrezerwacji=$_POST['datastartrezerwacji'];
$datakoniecrezerwacji=$_POST['datakoniecrezerwacji'];
$idpokoju=$_POST['idpokoju'];
$idparkingu=$_POST['idparkingu'];
$zrealizowane=$_POST['zrealizowane'];


$sql = "INSERT INTO rezerwacje(id_rezerwacji,id_klient,data_start_rezerwacji,data_koniec_rezerwacji,id_pokoju,id_parking,zrealizowane)
VALUES ('$idrezerwacji','$idklienta','$datastartrezerwacji','$datakoniecrezerwacji','$idpokoju','$idparkingu','$zrealizowane')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
  
  $conn->close();
  ?>