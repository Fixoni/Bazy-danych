<?php
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>wypisywanie danych klientów</title>
</head>
<body>
<a href="biuro.html"> <input type="submit" value="wróć"></a>
    <?php
    $polaczenie=mysqli_connect('localhost','root','','hotele')
    or die('błąd połączenia');

    $zapytanie1='select * from klienci;';

    //podpiecie zapytania do bazy danych
    $wynik1=mysqli_query($polaczenie,$zapytanie1);

    //wypisanie wynikow zapytania
    while($wiersz1=mysqli_fetch_assoc($wynik1))
    {
        echo $wiersz1['id_klient'];
        echo " ";
        echo $wiersz1['imie'];
        echo " ";
        echo $wiersz1['nazwisko'];
        echo " ";
        echo $wiersz1['id_kraju'];
        echo " ";
        echo $wiersz1['id_miasto'];
        echo " ";
        echo $wiersz1['adres'];
        echo " ";
        echo $wiersz1['licznik'];
        echo " ";
        echo $wiersz1['nr_dokumentacji'];
        echo " ";
        echo "</br>";
    }