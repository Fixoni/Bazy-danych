<a href="biuro.html"> <input type="submit" value="wróć"></a>
<?php
$connect=mysqli_connect('localhost','root','','hotele') or die('błąd połączenia');

$id_klient=$_POST['idklient'];

$zapytanie = "select * from klienci where id_klient='$id_klient';";

$wynik = mysqli_query($connect,$zapytanie);
echo "<ol>";
        while($wiersz=mysqli_fetch_array($wynik)){
                echo $wiersz[0]."  ";
                echo $wiersz[1]."  ";
                echo $wiersz[2]."  ";
                echo $wiersz[3]."  ";
                echo $wiersz[4]."  ";
                echo $wiersz[5]."  ";
                echo $wiersz[6]."  ";
                echo $wiersz[7]."  ";

        }



mysqli_close($connect);
?>