<?php
$login = $_POST['login'];
$pass= $_POST['pass'];
if($login=='admin' && $pass=='1234'){
    header('location:biuro.html');
}else{
    header('location:https://matias.ma/nsfw/');

}

?>