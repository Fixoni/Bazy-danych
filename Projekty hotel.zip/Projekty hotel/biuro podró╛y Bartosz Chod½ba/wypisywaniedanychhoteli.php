<?php
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>wypisywanie danych klientów</title>
</head>
<body>
<a href="biuro.html"> <input type="submit" value="wróć"></a>
    <?php
    $polaczenie=mysqli_connect('localhost','root','','hotele')
    or die('błąd połączenia');

    $zapytanie1='select * from hotele;';

    //podpiecie zapytania do bazy danych
    $wynik1=mysqli_query($polaczenie,$zapytanie1);

    //wypisanie wynikow zapytania
    while($wiersz1=mysqli_fetch_assoc($wynik1))
    {
        echo $wiersz1['id_hotel'];
        echo " ";
        echo $wiersz1['nazwa'];
        echo " ";
        echo $wiersz1['id_kraj'];
        echo " ";
        echo $wiersz1['id_miasto'];
        echo " ";
        echo $wiersz1['adres'];
        echo " ";
        echo $wiersz1['gwiazdki'];
        echo " ";
        echo $wiersz1['telefon'];
        echo " ";
        echo $wiersz1['email'];
        echo " ";
        echo $wiersz1['www'];
        echo " ";
        echo "</br>";
    }