<a href="biuro.html"> <input type="submit" value="wróć"></a>
<?php

$connect=mysqli_connect('localhost','root','','hotele') or die('błąd połączenia');

$nazwa=$_POST['naz'];

$zapytanie = "select * from hotele where nazwa='$nazwa';";

$wynik = mysqli_query($connect,$zapytanie);

echo "<ol>";
        while($wiersz=mysqli_fetch_array($wynik)){
                echo $wiersz[0]."  ";
                echo $wiersz[1]."  ";
                echo $wiersz[2]."  ";
                echo $wiersz[3]."  ";
                echo $wiersz[4]."  ";
                echo $wiersz[5]."  ";
                echo $wiersz[6]."  ";
                echo $wiersz[7]."  ";
                echo $wiersz[8]."  ";

        }



mysqli_close($connect);
?>