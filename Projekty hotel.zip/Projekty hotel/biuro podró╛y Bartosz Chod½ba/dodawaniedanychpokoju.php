<?php


$idhotel=$_POST['idhotel'];
$nrpokoju=$_POST['nrpokoju'];
$pietro=$_POST['pietro'];
$ludzie=$_POST['ludzie'];

$conn=@mysqli_connect('localhost','root','','hotele') or die('Błąd połączenia/bazy');
$sql = "INSERT INTO pokoje(id_hotel,nr_pokoju,pietro,ludzie)
VALUES('$idhotel','$nrpokoju','$pietro','$ludzie')";
$add=mysqli_query($conn,$sql);
if ($add) {
    echo "Dodano dane pokoju";
  } else {
    echo "Nie dodano";
  }
  
  mysqli_close($conn);
  ?>