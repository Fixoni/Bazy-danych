<a href="biuro.html"> <input type="submit" value="wróć"></a>
<?php

$connect=mysqli_connect('localhost','root','','hotele') or die('błąd połączenia');

$idpokoju=$_POST['idpokoju'];

$zapytanie = "select * from pokoje where id_pokoju='$idpokoju';";

$wynik = mysqli_query($connect,$zapytanie);

echo "<ol>";
        while($wiersz=mysqli_fetch_array($wynik)){
                echo $wiersz[0]."  ";
                echo $wiersz[1]."  ";
                echo $wiersz[2]."  ";
                echo $wiersz[3]."  ";
                echo $wiersz[4]."  ";

        }



mysqli_close($connect);
?>