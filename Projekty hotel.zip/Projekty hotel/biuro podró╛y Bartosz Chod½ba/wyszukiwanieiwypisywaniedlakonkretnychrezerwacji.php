<?php
$id_rezerwacji=$_POST['id_rezerwacji'];
$id_klient=$_POST['id_klient'];


$connect=@mysqli_connect('localhost','root','','hotele') or die('błąd połączenia');

$zapytanie="select * from rezerwacje where id_rezerwacji='$id_rezerwacji.' and id_klient='$id_klient.';";


$wynik=mysqli_query($connect,$zapytanie);
echo "<table>";
while($wiersz=mysqli_fetch_array($wynik)){
    echo"<tr>";
    echo"<th>"."id_rezerwacji:"."</th>";
    echo"<th>"."id_klient:"."</th>";
    echo"<th>"."data_start_rezerwacji:"."</th>";
    echo"<th>"."data_koniec_rezerwacji:"."</th>";
    echo"<th>"."id_pokoju:"."</th>";
    echo"<th>"."id_parking:"."</th>";
    echo"<th>"."zrealizowane:"."</th>";
    
    echo"</tr>";
    
    echo"<tr>";
    echo"<td>".$wiersz['id_rezerwacji']."</th>";
    echo"<td>".$wiersz['id_klient']."</th>";
    echo"<td>".$wiersz['data_start_rezerwacji']."</th>";
    echo"<td>".$wiersz['data_koniec_rezerwacji']."</th>";
    echo"<td>".$wiersz['id_pokoju']."</th>";
    echo"<td>".$wiersz['id_parking']."</th>";
    echo"<td>".$wiersz['zrealizowane']."</th>";
    
   
    echo"</tr>";    
    
   

   


    
   
  

    
    echo "</table>";
}



?>