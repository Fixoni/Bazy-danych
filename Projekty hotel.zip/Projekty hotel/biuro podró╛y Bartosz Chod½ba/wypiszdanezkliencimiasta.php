<?php
?>
<html lang="pl">
<head>
<meta charset="UTF-8">    
<title>dane klienci i miasta</title>
</head>
<body>
<?php
$connect=@mysqli_connect('localhost','root','','hotele') or die('błąd połączenia');
$zapytanie1="select nazwisko, id_miasto from klienci group by nazwisko, id_miasto;";
$wynik1=mysqli_query($connect,$zapytanie1);
echo "<table>";
while($wiersz=mysqli_fetch_array($wynik1)){
    echo "<table>";
    echo "<tr>";
    echo "<th>"."Nazwisko:"."</th>";
     echo "<th>"."id_miasto:"."</th>";
     echo "</tr>";
    echo "<tr>";
    echo "<td>".$wiersz['nazwisko']."</td>";
     echo "<td>".$wiersz['id_miasto']."</td>";
     echo "</tr>";
    echo "</table>";
}
?>