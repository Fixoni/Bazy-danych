<!DOCTYPE html>
<html>
<head>
	<title>Dodaj rezerwację</title>
   
</head>
<body>
<a href="biuro.html"> <input type="submit" value="wróć"></a>
	<h2>Dodaj rezerwację</h2>
    <link rel="stylesheet" href="rdk.css">
    <form action="skryptddkr.php" method="post">   
    <label for="id_klient">ID klienta:</label>
        <select id="id_klient" name="id_klient">

       
        <?php
           $connect = mysqli_connect('localhost','root','','hotele') or die('błąd połączenia');
            
            $query = "SELECT id_klient FROM klienci";
            $result = mysqli_query($connect, $query);

        
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<option style='color:blue;'value='" . $row['id_klient'] . "'>" . $row['id_klient'] . "</option>";
            }

            mysqli_close($connect);
        ?>
        </select><br>
        <label for="checkin">Data zameldowania:</label>
        <input type="date" id="checkin" name="checkin"><br>
      
        <label for="checkout">Data wymeldowania:</label>
        <input type="date" id="checkout" name="checkout"><br>
        <label for="pokoj">Numer pokoju:</label>
        <input type="text" id="pokoj" name="pokoj"><br>
        <label for="pokoj">ID parking</label>
        <input type="number" id="parking" name="number"><br>
        <label>Zrealizowane?</label>
        <input type="radio" name="zrealizowane" id="zrealiowane">Tak</input>
        <input type="radio" name="zrealizowane" id="zrealiowane">Nie</input>
        <br>

  
      
        <input type="submit" value="Zarezerwuj">
    </form>
   
</body>
</html>