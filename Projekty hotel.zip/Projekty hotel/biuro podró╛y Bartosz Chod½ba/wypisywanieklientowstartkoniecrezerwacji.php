<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wypisywanie danych klientów - rezerwacja w danym terminie</title>
</head>
<body>

<?php
if(isset($_POST['datapoczatek'],$_POST['datakoniec'])) {
    $conn=@mysqli_connect('localhost','root','','hotele') or die('Błąd połączenia');


    $datapoczatek = $_POST['datapoczatek'];
    $datakoniec = $_POST['datakoniec'];


    $sql = "SELECT klienci.imie, klienci.nazwisko, rezerwacje.data_start_rezerwacji,rezerwacje.data_koniec_rezerwacji FROM rezerwacje rezerwacje 
    JOIN klienci klienci ON rezerwacje.id_klient = klienci.id_klient 
    WHERE rezerwacje.data_start_rezerwacji BETWEEN '$datapoczatek' AND '$datakoniec' OR rezerwacje.data_koniec_rezerwacji BETWEEN '$datapoczatek' AND '$datakoniec'";


$wynik = mysqli_query($conn,$sql);
echo "<table border=2>";
echo "<tr>
        <th>imie</th>
        <th>nazwisko</th>
        <th>początek rezerwacji</th>
        <th>koniec rezerwacji</th>
    </tr>";
    
while($wiersz = mysqli_fetch_array($wynik)){
    echo "<tr>";
    echo "<td>".$wiersz['imie']."</td>";
    echo "<td>".$wiersz['nazwisko']."</td>";
    echo "<td>".$wiersz['data_start_rezerwacji']."</td>";
    echo "<td>".$wiersz['data_koniec_rezerwacji']."</td>";
    echo "</tr>";
}
echo "</table>";

    mysqli_close($conn);
}
?>
</body>
</html>