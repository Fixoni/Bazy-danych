<?php
// Połączenie z bazą danych
$conn=mysqli_connect('localhost','root','','hotele')
or die("błąd połączenia");


// Pobranie danych z formularza
$id_hotel = $_POST["idhotel"];
$nazwa = $_POST["nazwa"];
$id_kraj= $_POST["idkraj"];
$id_miasto = $_POST["idmiasto"];
$adres = $_POST["adres"];
$gwiazdki = $_POST["gwiazdki"];
$telefon = $_POST["telefon"];
$email = $_POST["email"];
$www = $_POST['www'];

// Aktualizacja danych hotelu
$sql = "UPDATE klienci SET id_hotel='$id_hotel', nazwa='$nazwa',  id_kraj='$id_kraj' ,  id_miasto='$id_miasto',     adres='$adres'  , gwiazdki='$gwiazdki',     telefon='$telefon', $email='email', $www='www' WHERE id_hotel='$id_hotel'";

$upd=mysqli_query($conn,$sql);
    if($upd){
        echo "Zaktualizowano dane";
    }

    mysqli_close($connect);
?>