<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Dodawanie rezerwacji</title>
</head>
<body>
    <a href="index.html"> <input type="submit" value="wróć"></a>
    <form method="POST" action="dane_rezerwacji.php">
        <link rel="stylesheet" href="dane.css">
        <h2>Dodawanie rezerwacji</h2>
        <label>Podaj nr rezerwacji</label>
        <input type="text" name="nr_rezerwacji" required/>
        <br/>
        <label>Podaj nr klienta</label>
        <input type="text" name="klient" required/>
        <br/>
        <label>Podaj date rozpoczęcia rezerwacji</label>
        <input type="date" name="od" required/>
        <br>
        <label>Podaj date zakończenia rezerwacji</label>
        <input type="date" name="do" required/>
        <br/>
        <label>Podaj nr pokoju</label>
        <input type="text" name="nr_pokoju" required/>
        <br>
        <label>Podaj nr parkingu</label>
        <input type="text" name="nr_parking" required/>
        <br>
        <label>Zrealizowane?</label>
        <input type="radio" name="zrealizowane">Tak</input>
        <input type="radio" name="zrealizowane">Nie</input>
        <br>
        
        <input type="submit" value="Dodaj rezerwację"/>
        <input type="reset" value="Usuń wszystkie wartości">
        <br>
    </form>
</body>
</html>
<?php
error_reporting(0);
include('polacz.php');
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
  }
$nr_rezerwacji=$_POST['nr_rezerwacji'];
$klient=$_POST['klient'];
$od=$_POST['od'];
$do=$_POST['do'];
$nr_pokoju=$_POST['nr_pokoju'];
$nr_parking=$_POST['nr_parking'];
$zrealizowane=$_POST['zrealizowane'];


$zapytanie1 = "INSERT INTO rezerwacje(id_rezerwacji,id_klient,data_start_rezerwacji,data_koniec_rezerwacji,id_pokoju,id_parking,zrealizowane)
VALUES ('$nr_rezerwacji','$klient','$od','$do','$nr_pokoju','$nr_parking','$zrealizowane')";

if ($connect->query($zapytanie1) === TRUE) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $zapytanie1 . "<br>" . $connect->error;
  }
  
  mysqli_close($connect);
  ?>