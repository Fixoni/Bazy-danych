<?php
?>
<html lang="pl">
<head>
<meta charset="UTF-8">    
<title>Dane klient/miasto</title>
<link rel="stylesheet" href="wypisywanie.css">
</head>
<body>
<?php
error_reporting(0);
include('polacz.php');
$zapytanie1="select nazwisko, id_miasto from klienci group by nazwisko, id_miasto;";
$wynik1=mysqli_query($connect,$zapytanie1);
echo "<table>";
while($wiersz=mysqli_fetch_array($wynik1)){
    echo "<table>";
    echo "<tr>";
    echo "<th>"."Nazwisko:"."</th>";
     echo "<th>"."id_miasto:"."</th>";
     echo "</tr>";
    echo "<tr>";
    echo "<td>".$wiersz['nazwisko']."</td>";
     echo "<td>".$wiersz['id_miasto']."</td>";
     echo "</tr>";
    echo "</table>";
}
?>