<!DOCTYPE html>
<html lang="pl">
<head>
	<title>Szukaj klientów więcej niż raz</title>
	<link rel="stylesheet" href="wyszukiwanie.css">
</head>
<body>
	<h2>Szukaj klientów więcej niż raz w danym hotelu</h2>
	<form action="klienci_wiecejod1.php" method="post">
		<label for="hotel">Nazwa hotelu:</label>
		<input type="text" id="hotel" name="hotel"><br><br>
		<input type="submit" value="Szukaj">
	</form>
</body>
</html>
<?php
error_reporting(0);
include('polacz.php');
$zapytanie1 = "SELECT klienci. * FROM rezerwacje JOIN klienci ON rezerwacje.id_klient = klienci.id_klient WHERE rezerwacje.zrealizowane = 1 HAVING COUNT(zrealizowane) > 1";
$wynik = mysqli_query($connect, $zapytanie1);
if (!$wynik) {
    die("Błąd zapytania: " . mysqli_error($connect));
}
if (mysqli_num_rows($wynik) > 0) {
    while ($wiersz = mysqli_fetch_assoc($wynik)) {
        echo "ID klienta: " . $wiersz["id_klient"] . " - Imię i nazwisko: " . $wiersz["imie"] . " " . $wiersz["nazwisko"] . "<br>";
    }
} else {
    echo "Brak wyników.";
}
mysqli_close($connect);
?>