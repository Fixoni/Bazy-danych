
<?php

$login=$_POST['log'];
$pass=$_POST['pass'];
if($login=="admin" && $pass=="123"){
    header('location:hotel.html');
}else{
    echo 'Hasło niepoprawne';
}
?>