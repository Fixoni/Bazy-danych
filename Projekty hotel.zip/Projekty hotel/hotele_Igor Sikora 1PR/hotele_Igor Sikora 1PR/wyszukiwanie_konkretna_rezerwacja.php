<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8"> 
        <title>Konkretnego rezerwacja dane</title>
        <link rel="stylesheet" href="wyszukiwanie_wypisywanie.css">
    </head>
    <body>
        <div class="container">
        <form method="POST" action="wyszukiwanie_konkretna_rezerwacja.php">
            <h2>Wyszukiwanie rezerwacji</h2>
            <label>Nr rezerwacji:</label>
            <input type="number" name="nr_rezerwacji" required/>
            <label>Nr klienta:</label>
            <input type="number" name="klient" required/>
            <input type="submit" class="pr" value="Wyszukaj"/>
            <input class="pr" type="reset"/>
            
        </form>
        </div>
    </body>
</html>
<?php
error_reporting(0);
include('polacz.php');
$nr_rezerwacji=$_POST['nr_rezerwacji'];
$klient=$_POST['klient'];
$zapytanie1="select * from rezerwacje where id_rezerwacji='$nr_rezerwacji.' and id_klient='$klient.';";
$wynik=mysqli_query($connect,$zapytanie1);
echo "<table>";
while($wiersz=mysqli_fetch_array($wynik)){
    echo"<tr>";
    echo"<td>"."nr_rezerwacji:"."</td>";
    echo"<td>"."klient:"."</td>";
    echo"<td>"."data_start_rezerwacji:"."</td>";
    echo"<td>"."data_koniec_rezerwacji:"."</td>";
    echo"<td>"."id_pokoju:"."</td>";
    echo"<td>"."id_parking:"."</td>";
    echo"<td>"."zrealizowane:"."</td>";
    echo"</tr>";
    
    echo"<tr>";
    echo"<td>".$wiersz['nr_rezerwacji']."</td>";
    echo"<td>".$wiersz['klient']."</td>";
    echo"<td>".$wiersz['data_start_rezerwacji']."</td>";
    echo"<td>".$wiersz['data_koniec_rezerwacji']."</td>";
    echo"<td>".$wiersz['id_pokoju']."</td>";
    echo"<td>".$wiersz['id_parking']."</td>";
    echo"<td>".$wiersz['zrealizowane']."</td>";
    echo"</tr>";    
}
echo "</table>";


?>