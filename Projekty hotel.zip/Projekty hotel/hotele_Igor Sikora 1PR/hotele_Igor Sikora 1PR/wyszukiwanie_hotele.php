<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Szukaj hotelu</title>
</head>
<body>
    <link rel="stylesheet" href="wyszukaj.css">
    <a href="index.html"><input type="button" value="powrot"></a>
    <form method="POST" action="wyszukiwanie_hotele.php">
        <h2>Podaj dane hotelu</h2>
        <label>Nazwa</label>
        <input type="text" name="naz" required>
        </br>
        <input type="submit" value="znajdź hotel">
        <input type="reset">
    </form>
</body>
</html>
<a href="biuro.html"> <input type="submit" value="wróć"></a>
<?php
error_reporting(0);
include('polacz.php');
$nazwa=$_POST['naz'];
$zapytanie = "select * from hotele where nazwa='$nazwa';";
$wynik = mysqli_query($connect,$zapytanie);
echo "<ol>";
        while($wiersz=mysqli_fetch_array($wynik)){
                echo $wiersz[0]."  ";
                echo $wiersz[1]."  ";
                echo $wiersz[2]."  ";
                echo $wiersz[3]."  ";
                echo $wiersz[4]."  ";
                echo $wiersz[5]."  ";
                echo $wiersz[6]."  ";
                echo $wiersz[7]."  ";
                echo $wiersz[8]."  ";

        }
mysqli_close($connect);
?>