<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodawanie rezewacji konkretnego klienta</title>
</head>
<body>
<?php
    include('polacz.php');
    
    $zapytanie1 = "SELECT id_klient, imie, nazwisko FROM klienci";
    $wynik = $connect->query($zapytanie1);
    if ($wynik->num_rows > 0) {
        
        echo '<form method="POST" action="rezerwacja_konkretny_klient">';
        echo '<label>Wybierz klienta:</label>';
        echo '<select name="idKlienta">';
        while($wiersz = $wynik->fetch_assoc()) {
            echo '<option value="' . $wynik["id_klienta"] . '">' . $wynik["imie"] . ' ' . $wynik["nazwisko"] . '</option>';
        }
        echo '</select>';
        echo '<br>';
        echo '<label>Podaj datę rozpoczęcia (RRRR-MM-DD):</label>';
        echo '<input type="text" name="dataRozpoczecia">';
        echo '<br>';
        echo '<label>Podaj datę zakończenia (RRRR-MM-DD):</label>';
        echo '<input type="text" name="dataZakonczenia">';
        echo '<br>';
        echo '<label>Podaj ID pokoju:</label>';
        echo '<input type="number" name="idPokoju">';
        echo '<br>';
        echo '<input type="submit" value="Dodaj rezerwację">';
        echo '</form>';
    } else {
        echo "Nie znaleziono klientów.";
    }
    
    myzapytanie1i_close($connect);
?>
</body>
</html>