<?php
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Wypisanie danych pokoje</title>
    <link rel="stylesheet" href="pokoje.css">
</head>
<body>
<a href="index.html"> <input type="submit" value="wróć"></a>
    <?php
error_reporting(0);
include('polacz.php');
    $zapytanie1='select * from pokoje;';
    $wynik1=mysqli_query($polaczenie,$zapytanie1);
    
    echo "<table border=1>";
    echo "<tr><th>id pokoju</th>
        <th>id hotel</th>
        <th>ne pokoju</th>
        <th>piętro</th>
        <th>ludzie</th>
    </tr>";
    while($wiersz1=mysqli_fetch_assoc($wynik1))
    {
        echo "<tr>";
        echo "<td>".$wiersz1['id_pokoju']."</td>";
        echo "<td>".$wiersz1['id_hotel']."</td>";
        echo"<td>".$wiersz1['nr_pokoju']."</td>";
        echo "<td>".$wiersz1['pietro']."</td>";
        echo "<td>".$wiersz1['ludzie']."</td>";
        echo "<tr>";
    }
    echo "</table>";
    mysqli_close($connect);
?>