<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Szukaj klienta</title>
</head>
<body>
    <link rel="stylesheet" href="wyszukiwanie.css">
    <a href="index.html"><input type="button" value="powrot"></a>
    <form method="POST" action="wyszukiwanie_klienci.php">
        <h2>Wyszukaj klienta</h2>
        <label>Podaj nr klienta</label>
        <input type="text" name="klient" required>
        </br>
        <input type="submit" value="znajdź klienta">
        <input type="reset">
    </form>
</body>
</html>
<a href="index.html"> <input type="submit" value="wróć"></a>
<?php
error_reporting(0);
include('polacz.php');
$klient=$_POST['klient'];
$zapytanie = "select * from klienci where id_klient='$klient';";
$wynik = mysqli_query($connect,$zapytanie);
echo "<ol>";
        while($wiersz=mysqli_fetch_array($wynik)){
                echo $wiersz[0]."  ";
                echo $wiersz[1]."  ";
                echo $wiersz[2]."  ";
                echo $wiersz[3]."  ";
                echo $wiersz[4]."  ";
                echo $wiersz[5]."  ";
                echo $wiersz[6]."  ";
                echo $wiersz[7]."  ";

        }



mysqli_close($connect);
?>