<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Dodawanie danych pokoju</title>
    <link rel="stylesheet" href="dane.css">
</head>
<body>
    <a href="index.html"> <input type="submit" value="wróć"></a>
    <form method="POST" action="pokoje.php">
        <link rel="stylesheet" href="dk.css"> 
        <h2>Dodawanie danych pokoju</h2>
        <label>Podaj nr hotelu</label>
        <input type="text" name="hotel" required/>
        <br/>
        <label>Podaj numer pokoju </label>
        <input type="text" name="nrpokoju" required/>
        <br>
        <label>Podaj pietro</label>
        <input type="text" name="pietro" required/>
        <br/>
        <label>Podaj liczbe ludzi</label>
        <input type="text" name="ludzie" required/>
        <br>
        <input type="submit" value="dodaj dane"/>
        <input type="reset" value="Usuń wszystkie wartości">
        <br>
    </form>
</body>
</html>
<?php
error_reporting(0);
$hotel=$_POST['hotel'];
$nrpokoju=$_POST['nrpokoju'];
$pietro=$_POST['pietro'];
$ludzie=$_POST['ludzie'];

include('polacz.php');
$zapytanie1 = "INSERT INTO pokoje(id_hotel,nr_pokoju,pietro,ludzie)
VALUES('$hotel','$nrpokoju','$pietro','$ludzie')";
$wynik=mysqli_query($connect,$zapytanie1);
if ($wynik) {
    echo "Dodano dane pokoju";
  } else {
    echo "Nie dodano";
  }
  mysqli_close($connect);
  ?>