<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wyszukiwanie danych klientów</title>
    <link rel="stylesheet" href="wyszukiwanie.css">
</head>
<body>
<form method="POST" action="wyszukiwanie_nazwisko.php">
<h2>Podaj nazwisko do wyszukania</h2>
<input type="text" name="naz" required/>
<br/>
<input type="submit" value="Znajdź"/>
<input type="reset" />
</form>
</body>
<?php
error_reporting(0);
include('polacz.php');

$nazwisko=$_POST['naz'];

$wyszukaj=mysqli_query($connect,"select * from klienci where nazwisko='$nazwisko';");

$ileNazwisk=mysqli_num_rows($wyszukaj);

echo " osób o nazwisku " .$nazwisko." jest : ".$ileNazwisk;
if($ileNazwisk>0){
echo "<select name='nazwisko'>";
while($wiersz=mysqli_fetch_array($wyszukaj)){
echo "<option >"
   .$wiersz[0]." " .$wiersz[1]." ".$wiersz[2].
    "</option>";

}
echo"</select>";
}
mysqli_close($connect);
?>
</html>