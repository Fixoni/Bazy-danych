<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="wyszukiwanie.css">
    <title>Konkretan data</title>
</head>
<body>
<a href="index.html"> <input type="submit" value="wróć"></a>
<form method="POST" action="wyszukiwanie_konkretna_data.php">
    <h2>Wpisz datę rozpoczęcia i zakończenia rezerwacji</h2>
    <p>Początwk</p>
    <input type="date" name="od" required/>
    <br/>
    <p>Zakończenie</p>
    <input type="date" name="do" required/>
    <br/>
    <input type="submit" value="Wyszukaj"/>
    <input type="reset" />
</form>
</body>
</html>
<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wypisywanie klientó kontretny termin</title>
</head>
<body>

<?php
if(isset($_POST['od'],$_POST['do'])) {
    error_reporting(0);
    include('polacz.php');
    $od = $_POST['od'];
    $do = $_POST['do'];
    $zapytanie1 = "SELECT klienci.imie, klienci.nazwisko, rezerwacje.data_start_rezerwacji,rezerwacje.data_koniec_rezerwacji FROM rezerwacje rezerwacje 
    JOIN klienci klienci ON rezerwacje.id_klient = klienci.id_klient 
    WHERE rezerwacje.data_start_rezerwacji BETWEEN '$od' AND '$do' OR rezerwacje.data_koniec_rezerwacji BETWEEN '$od' AND '$do'";
$wynik = myzapytanie1i_query($connect,$zapytanie1);
echo "<table border=2>";
echo "<tr>
        <th>imie</th>
        <th>nazwisko</th>
        <th>początek rezerwacji</th>
        <th>koniec rezerwacji</th>
    </tr>";
    
while($wiersz = myzapytanie1i_fetch_array($wynik)){
    echo "<tr>";
    echo "<td>".$wiersz['imie']."</td>";
    echo "<td>".$wiersz['nazwisko']."</td>";
    echo "<td>".$wiersz['data_start_rezerwacji']."</td>";
    echo "<td>".$wiersz['data_koniec_rezerwacji']."</td>";
    echo "</tr>";
}
echo "</table>";

    myzapytanie1i_close($connect);
}
?>
</body>
</html>