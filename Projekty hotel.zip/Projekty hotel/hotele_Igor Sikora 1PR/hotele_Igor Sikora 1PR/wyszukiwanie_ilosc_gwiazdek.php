<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
	<title>Wyszukiwanie po gwiazdkach</title>
    <link rel="stylesheet" href="gwiazdki.css">
</head>
<body>
    <a href="index.html"> <input type="submit" value="wróć"></a>
	<form method="post" action="wyszukiwanie_ilosc_gwiazdek.php">
        <h2>Wyszukaj ile klientów było w hotelu o określonej ilości gwiazdek</h2>
		<label>Liczba gwiazdek to:</label>
		<input type="number" name="gwiazdki" min="1" max="30" required>
		<br><br>
		<input type="submit" name="submit" value="Wyszukaj">
	</form>
</body>
</html>
<?php
error_reporting(0);
include('polacz.php');
$gwiazdki = $_POST["gwiazdki"];
$zapytanie = "SELECT COUNT(*) as ilosc_klientow FROM hotele WHERE gwiazdki = $gwiazdki";
$wynik = $connect->query($zapytanie);
if ($wynik->num_rows > 0) {
	while($wiersz = $wynik->fetch_assoc()) {
		echo "<p>Ilość klientów w hotelach $gwiazdki-gwiazdkowych: " . $wiersz["ilosc_klientow"] . "</p>";
	}
} else {
	echo "Brak wyników.";
}
mysqli_close($connect);
?>