<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dane klienta</title>
    <link rel="stylesheet" href="wypisywanie.css">
</head>
<body>
<?php
        include('polacz.php');
        $zapytanie1 = "select * from klienci";
        $wynik = mysqli_query($connect,$zapytanie1);

    echo "<table border=1>";
    echo "<tr><th>id klienta</th>
        <th>imie</th>
        <th>nazwisko</th>
        <th>id kraju</th>
        <th>id miasto</th>
        <th>adres</th>
        <th>liczba osób w pokoju</th>
        <th>nr dokumentacji</th>
    </tr>";
    while($wiersz = mysqli_fetch_array($wynik)){
    echo "<tr>";
    echo "<td>".$wiersz['id_klient']."</td>";
    echo "<td>".$wiersz['imie']."</td>";
    echo "<td>".$wiersz['nazwisko']."</td>";
    echo "<td>".$wiersz['id_kraju']."</td>";
    echo "<td>".$wiersz['id_miasto']."</td>";
    echo "<td>".$wiersz['adres']."</td>";
    echo "<td>".$wiersz['licznik']."</td>";
    echo "<td>".$wiersz['nr_dokumentacji']."</td>";
    echo "</tr>";
    }
echo "</table>";

mysqli_close($connect);
?>
</body>
</html>