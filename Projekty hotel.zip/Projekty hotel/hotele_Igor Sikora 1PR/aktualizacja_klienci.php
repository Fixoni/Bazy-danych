<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aktualizacja danych klientów</title>
</head>
<body>
<form method="POST" action="aktualizacja_klientow.php">
    <label>Podaj id klienta</label>
    <input type="text" name="imie" />
    <br/>
<label>Podaj imię</label>
    <input type="text" name="imie" />
    <br/>
    <label>Podaj nazwisko</label>
    <input type="text" name="nazwisko" />
    <br>
    <label>Podaj nr kraju</label>
    <input type="number" name="kraj" />
    <br/>
    <label>Podaj nr miasta</label>
    <input type="number" name="miasto" />
    <br>
    <label>Podaj adres</label>
    <input type="text" name="adres" />
    <br>
    <label>Podaj liczbę osób w pokoju</label>
    <input type="number" name="licznik" />
    <br>
    <label>Podaj numer dokumentacji</label>
    <input type="number" name="dokumentacja" />
    <br>
    <input type="submit" value="Zaaktualizuj"/>
    <input type="reset" value="Usuń wszystkie wartości">
    <br>
</form>  
</body>
</html>
<?php
include('polacz.php');
$imie=$_POST['imie'];
$nazwisko=$_POST['nazwisko'];
$kraj=$_POST['kraj'];
$miasto=$_POST['miasto'];
$adres=$_POST['adres'];
$licznik=$_POST['licznik'];
$dokumentacja=$_POST['dokumentacja'];
$zapytanie1 = "SELECT id_klient FROM klienci";
$wynik = mysqli_query($connect, $zapytanie1);
$update = "UPDATE hotele_klienci
SET id_klient = $imie, nazwisko= $nazwisko, id_kraju = $kraj,id_miasto=$miasto,adres=$adres,licznik=$licznik,nr_dokumentacji=$dokumentacja
WHERE id_klient=id_klient;";
while ($wiersz = mysqli_fetch_assoc($wynik)) {
echo "<option value='" . $wiersz['id_klient'] . "'>" . $wiersz['id_klient'] . "</option>";
}
if($wynik){
echo "Zaaktualizowano pomyślnie";
}
else{
echo "Błąd przy aktualizacji";
}

mysqli_close($connect);
?>