-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2023 at 09:00 PM
-- Wersja serwera: 10.4.28-MariaDB
-- Wersja PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `hotele`
--

CREATE TABLE `hotele` (
  `id_hotel` int(11) NOT NULL,
  `nazwa` varchar(30) NOT NULL,
  `id_kraj` int(11) NOT NULL,
  `id_miasto` int(11) NOT NULL,
  `adres` varchar(50) NOT NULL,
  `gwiazdki` int(11) NOT NULL,
  `telefon` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `www` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hotele`
--

INSERT INTO `hotele` (`id_hotel`, `nazwa`, `id_kraj`, `id_miasto`, `adres`, `gwiazdki`, `telefon`, `email`, `www`) VALUES
(1, 'hilton', 4, 12, 'ulanow', 8, '6920872435', 'costam@gmial.com', 'www.www'),
(2, 'dsggggggg v', 18, 19, 'eadwww', 18, '23542624624261341436', 'gbsxfrdgsdfgsew', 'gedgaqwgaqwgaqwgaqwg');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `klienci`
--

CREATE TABLE `klienci` (
  `id_klient` int(11) NOT NULL,
  `imie` varchar(20) NOT NULL,
  `nazwisko` varchar(40) NOT NULL,
  `id_kraju` int(11) NOT NULL,
  `id_miasto` int(11) NOT NULL,
  `adres` varchar(50) NOT NULL,
  `licznik` int(11) NOT NULL,
  `nr_dokumentacji` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `klienci`
--

INSERT INTO `klienci` (`id_klient`, `imie`, `nazwisko`, `id_kraju`, `id_miasto`, `adres`, `licznik`, `nr_dokumentacji`) VALUES
(7, 'tomek', 'guz', 3, 1, 'sdafsdaf', 0, '2');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `kraje`
--

CREATE TABLE `kraje` (
  `id_kraju` int(11) NOT NULL,
  `nazwa_kraju` varchar(50) NOT NULL,
  `kod_kraju` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `miasta`
--

CREATE TABLE `miasta` (
  `id_miasto` int(11) NOT NULL,
  `nazwa_miasta` varchar(50) NOT NULL,
  `kod_miasta` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pokoje`
--

CREATE TABLE `pokoje` (
  `id_pokoju` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `nr_pokoju` int(11) NOT NULL,
  `pietro` int(11) NOT NULL,
  `ludzie` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pokoje`
--

INSERT INTO `pokoje` (`id_pokoju`, `id_hotel`, `nr_pokoju`, `pietro`, `ludzie`) VALUES
(24, 0, 0, 0, 0),
(25, 4, 4, 6, 7),
(26, 0, 0, 0, 0),
(27, 0, 0, 0, 0),
(28, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `rezerwacje`
--

CREATE TABLE `rezerwacje` (
  `id_rezerwacji` int(11) NOT NULL,
  `id_klient` int(11) NOT NULL,
  `data_start_rezerwacji` date NOT NULL,
  `data_koniec_rezerwacji` date NOT NULL,
  `id_pokoju` int(11) NOT NULL,
  `id_parking` int(11) NOT NULL,
  `zrealizowane` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rezerwacje`
--

INSERT INTO `rezerwacje` (`id_rezerwacji`, `id_klient`, `data_start_rezerwacji`, `data_koniec_rezerwacji`, `id_pokoju`, `id_parking`, `zrealizowane`) VALUES
(1, 5, '2023-04-03', '2023-04-17', 4, 7, b'1'),
(2, 5, '2023-04-03', '2023-04-17', 4, 7, b'1'),
(3, 5, '2023-04-03', '2023-04-17', 4, 7, b'1'),
(4, 5, '2023-04-03', '2023-04-17', 4, 7, b'1'),
(5, 1, '2023-04-03', '2023-04-17', 7, 2, b'1'),
(6, 1, '2023-04-03', '2023-04-21', 41, 5, b'1'),
(7, 7, '2023-03-31', '2023-04-23', 87, 31, b'1'),
(8, 0, '0000-00-00', '0000-00-00', 0, 0, b'0'),
(9, 0, '0000-00-00', '0000-00-00', 0, 0, b'0'),
(10, 0, '0000-00-00', '0000-00-00', 0, 0, b'0'),
(11, 0, '0000-00-00', '0000-00-00', 0, 0, b'0'),
(12, 0, '0000-00-00', '0000-00-00', 0, 0, b'0');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `hotele`
--
ALTER TABLE `hotele`
  ADD PRIMARY KEY (`id_hotel`);

--
-- Indeksy dla tabeli `klienci`
--
ALTER TABLE `klienci`
  ADD PRIMARY KEY (`id_klient`);

--
-- Indeksy dla tabeli `kraje`
--
ALTER TABLE `kraje`
  ADD PRIMARY KEY (`id_kraju`);

--
-- Indeksy dla tabeli `pokoje`
--
ALTER TABLE `pokoje`
  ADD PRIMARY KEY (`id_pokoju`);

--
-- Indeksy dla tabeli `rezerwacje`
--
ALTER TABLE `rezerwacje`
  ADD PRIMARY KEY (`id_rezerwacji`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hotele`
--
ALTER TABLE `hotele`
  MODIFY `id_hotel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `klienci`
--
ALTER TABLE `klienci`
  MODIFY `id_klient` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `kraje`
--
ALTER TABLE `kraje`
  MODIFY `id_kraju` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pokoje`
--
ALTER TABLE `pokoje`
  MODIFY `id_pokoju` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `rezerwacje`
--
ALTER TABLE `rezerwacje`
  MODIFY `id_rezerwacji` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
