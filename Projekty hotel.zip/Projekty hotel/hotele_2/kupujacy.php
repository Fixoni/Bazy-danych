<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dane klienta</title>
    <link rel="stylesheet" href="dane.css">
</head>
<body>
    <form method="POST" action="">
        <h1>Dane kupującego</h1>
        <label>Imie</label>
        <input type="text" name="im" required/>
        <br/>
        <label>Nazwisko</label>
        <input type="text" name="naz" required/>
        <br/>
        <label>Adres</label>
        <input type="text" name="adres" required/>
        <br/>
        <label>Dni</label>
        <input type="number" name="dni" required/>
        <br/>
        <label>Miasto</label>
        <input type="number" name="mia" required/>
        <br/>
        <label>Kraj</label>
        <input type="number" name="kr" required/>
        <br/>
        <input type="submit" value="Dodaj klienta"/>
        <input type="reset"/>
    </form>
</body>
</html>
<?php
error_reporting(0);
$imie=$_POST['im'];
$nazwisko=$_POST['naz'];
$adres=$_POST['adres'];
$miasto=$_POST['mia'];
$kraj=$_POST['kr'];


include('polacz.php');

$zapytanie="insert into hotele_klienci(imie,nazwisko,id_kraju,id_miasto,adres,licznik) 
values('$imie','$nazwisko',$kraj,$miasto,'$adres','$licznik');";
$wynik=mysqli_query($connect,$zapytanie);
    if($wynik==true){
        echo " Dodano klienta ".$nazwisko."do bazy klientów.";
        header('location:index.html');
    }else{
         echo" Nie dodano klienta ".$nazwisko." do bazy klientów. Błąd"; 
    }
mysqli_close($connect);
?>