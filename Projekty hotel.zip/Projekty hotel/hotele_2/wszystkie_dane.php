<!DOCTYPE HTML>
<html lang="pl">
<head>
        <meta charset="UTF-8">
        <title>Wypisywanie potrzebnych danych do dokumentacji</title>
    <link rel="stylesheet" href="wypisywanie.css">
</head>
<body>
        <h1>Dane klientów</h1>
        <?php
        //połączenie z bazą danych 
        include('polacz.php');
        //tworzenie zapyatania
        $zapytanie1="select * from hotele_klienci";
        //użycie zapytania
        $wynik=mysqli_query($connect,$zapytanie1); 
        //wypisanie danych z tablicy
        echo "<table border=1>";
        while($wiersz=mysqli_fetch_assoc($wynik)){
            echo "<tr>";
            echo "<td>".$wiersz["imie"]."</td>";
            echo "<td>".$wiersz["nazwisko"]."</td>";
            echo "<td>".$wiersz["adres"]."</td>";
            echo "<td>".$wiersz["licznik"]."</td>";       
            echo "<tr>";
        }
        echo "</table>";
        ?>
        <h1>Dane rezerwacji</h1>
        <?php
        include('polacz.php');
        echo "<br/>"; 
        $zapytanie2="select * from hotele_rezerwacje";
        $wynik2=mysqli_query($connect,$zapytanie2);
        echo "<table border=1>";
        while($wiersz2=mysqli_fetch_assoc($wynik2)){
            echo "<tr>";
            echo "<td>".$wiersz2["data_start_rezerwacji"]."</td>";
            echo "<td>".$wiersz2["data_koniec_rezerwacji"]."</td>";
            echo "<td>".$wiersz2["zrealizowane"]."</td>";       
            echo "<tr>";
        }
        echo "</table>";
        mysqli_close($connect); 
        ?>
        <h1>Dane hotelów</h1>
        <?php
        include('polacz.php');
        echo "<br/>"; 
        $zapytanie3="select * from hotele_hotele";
        $wynik3=mysqli_query($connect,$zapytanie3);
        echo "<table border=1>";
        while($wiersz3=mysqli_fetch_assoc($wynik3)){
            echo "<tr>";
            echo "<td>".$wiersz3["nazwa"]."</td>";
            echo "<td>".$wiersz3["adres"]."</td>";
            echo "<td>".$wiersz3["gwiazdki"]."</td>";
            echo "<td>".$wiersz3["telefon"]."</td>";     
            echo "<td>".$wiersz3["email"]."</td>";  
            echo "<td>".$wiersz3["www"]."</td>";  
            echo "</tr>";
        }
        echo "</table>";
        mysqli_close($connect); 
        ?>
        <?php
        include('polacz.php');
        echo "<br/>"; 
        $zapytanie4="select * from hotele_pokoje";
        $wynik4=mysqli_query($connect,$zapytanie4);
        while($wiersz4=mysqli_fetch_assoc($wynik4)){
            echo $wiersz4["nr_pokoju"];
            echo " ";
            echo $wiersz4["pietro"];
            echo "  ";
            echo $wiersz4["ludzie"];
            echo "<br/>"; 
        }
        //zamknięcie połczenia z bazą danych
        mysqli_close($connect); 
        ?>
</body>
</html>