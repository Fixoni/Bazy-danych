


<!DOCTYPE html>
<html>
<head>
	<title>Aktualizacja danych klienta</title>
    <link rel="stylesheet" type="text/css" href="dane.css">
</head>
<body>
	<h2>Aktualizacja danych klienta</h2>
    <form action="aktualizaja_klienci.php" method="post">
    <label for="id_klient">ID klienta:</label>
        <select id="id_klient" name="id_klient">
        <?php
           include('polacz.php');
     
$imie=$_POST['imie'];
$nazwisko=$_POST['nazwisko'];
$idKraju=$_POST['idKraju'];
$idMiasta=$_POST['idMiasta'];
$adres=$_POST['adres'];
$licznik=$_POST['licznik'];
$dokumentacja=$_POST['dokumentacja'];
            $query = "SELECT id_klient FROM hotele_klienci";
            $result = mysqli_query($connect, $query);
            $update = "UPDATE hotele_klienci
            SET id_klient = $imie, nazwisko= $nazwisko, id_kraju = $idKraju,id_miasto=$idMiasta,adres=$adres,licznik=$licznik,nr_dokumentacji=$dokumentacja
            WHERE id_klient=id_klient;
            ";
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<option value='" . $row['id_klient'] . "'>" . $row['id_klient'] . "</option>";
            }
            if($result){
                echo "Zaaktualizowano pomyślnie";
            }
            else{
                echo "Błąd przy aktualizacji";
            }

            mysqli_close($connect);
        ?>
        </select><br>
<label>Podaj imię</label>
    <input type="text" name="imie" />
    <br/>
    <label>Podaj nazwisko</label>
    <input type="text" name="nazwisko" />
    <br>
    <label>Podaj ID kraju</label>
    <input type="number" name="idKraju" />
    <br/>
    <label>Podaj ID miasta</label>
    <input type="number" name="idMiasta" />
    <br>
    <label>Podaj adres</label>
    <input type="text" name="adres" />
    <br>
    <label>Podaj liczbę osób w pokoju</label>
    <input type="number" name="licznik" />
    <br>
    <label>Podaj numer dokumentacji</label>
    <input type="number" name="dokumentacja" />
    <br>
    <input type="submit" value="Zaaktualizuj"/>
    <input type="reset" value="Usuń wszystkie wartości">
    <br>
      
</body>
</html>