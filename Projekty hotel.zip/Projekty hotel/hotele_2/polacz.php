<?php
$connect=@mysqli_connect('localhost','root','','hotel') or die('błąd połączenia bazy danych');
?>