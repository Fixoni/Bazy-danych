<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dane hotelu</title>
    <link rel="stylesheet" href="dane.css">

</head>
<body>
    <form method="POST" action="">
        <h1>Dane hotelu</h1>
        <label>Nazwa</label>
        <input type="text" name="nazwa" required/>
        <br/>
        <label>Adres</label>
        <input type="text" name="adress" required/>
        <br/>
        <label>Gwiazdki</label>
        <input type="number" name="gw" required/>
        <br/>
        <label>Telefon</label>
        <input type="text" name="tel" required/>
        <br/>
        <label>E-mail</label>
        <input type="text" name="email" required/>
        <br/>
        <label>Strona</label>
        <input type="text" name="str" required/>
        <br/>
        <label>Miasto</label>
        <input type="number" name="mias" required/>
        <br/>
        <label>Kraj</label>
        <input type="number" name="kra" required/>
        <br/>
        <input type="submit" value="Dodaj hotel"/>
        <input type="reset"/>
    </form>
</body>
</html>
<a href="index.html"></a>
<?php
error_reporting(0);
$email=$_POST['email'];
$telefon=$_POST['tel'];
$nazwa=$_POST['nazwa'];
$addres=$_POST['adress'];
$strona=$_POST['str'];
$gwiazdki=$_POST['gw'];
$miasto2=$_POST['mias'];
$kraj2=$_POST['kra'];


//echo $nazwisko." ".$stanowisko." ".$data;

// $connect=@mysqli_connect('localhost','root','','kurs') or die('błąd połączenia bazy danych');
include('polacz.php');

$zapytanie2="insert into hotele_hotele(nazwa,id_kraj,id_miasto,adres,gwiazdki,telefon,email,www) 
values('$nazwa',$kraj2,$miasto2,'$addres',$gwiazdki,'$telefon','$email','$strona');";
$wynik2=mysqli_query($connect,$zapytanie2);
if($wynik2==true){
    echo " Dodano dane ".$nazwa."do bazy hotelów.";
    header('location:index.html');
}else{
    echo" Nie dodano danych ".$nazwa." do bazy hotelów. Błąd"; 
}

mysqli_close($connect);
?>