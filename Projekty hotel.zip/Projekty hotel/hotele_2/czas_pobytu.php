<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Czas pobytu</title>
    <link rel="stylesheet" href="dane.css">

</head>
<body>
    <form method="POST" action="czas_pobytu.php">
        <h1>Czas pobytu</h1>
        <label>Początek pobytu</label>
        <input type="date" name="od" required/>
        <br/>
        <label>Koniec pobytu</label>
        <input type="date" name="do" required/>
        <br/>
        <label>Zrealizowane</label>
        <input type="checkbox" name="wybor" required/>
        <br/>
        <input type="submit" value="Dodaj termin"/>
        <input type="reset"/>
    </form>
</body>
</html>
<?php
error_reporting(0);
$zrealizowane=$_POST['wybor'];
$od=$_POST['od'];
$do=$_POST['do'];
if($od!='' && $do!=''){

//echo $nazwisko." ".$stanowisko." ".$data;

// $connect=@mysqli_connect('localhost','root','','kurs') or die('błąd połączenia bazy danych');
include('polacz.php');

$zapytanie3="insert into hotele_rezerwacje(data_start_rezerwacji, data_koniec_rezerwacji, zrealizowane)
values('$od','$do','$zrealizowane');";
$wynik3=mysqli_query($connect,$zapytanie3);
/*}
if($wynik3==true){*/
    echo " Dodano dane ".$od."//".$do."do bazy hotelów.";
    header('location:index.html');
}else
/* if($wynik3==false)*/{
    //header('location:czas_pobytu.php');
   // echo" Nie dodano danych ".$od."//".$do." do bazy hotelów. Błąd"; 
}
mysqli_close($connect);
?>