<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pokoje</title>
    <link rel="stylesheet" href="dane.css">

</head>
<body>
    <form method="POST" action="pokoje.php">
        <h1>Pokoje</h1>
        <label>Nr pokuju</label>
        <input type="number" name="pk" required/>
        <br/>
        <label>Pietro</label>
        <input type="number" name="pietro" required/>
        <br/>
        <label>Ilość osób</label>
        <input type="number" name="os" required/>
        <br/>
        <input type="submit" value="Dodaj"/>
        <input type="reset"/>
    </form>
</body>
</html>
<?php
error_reporting(0);
$pk=$_POST['pk'];
$pietro=$_POST['pietro'];
$osoby=$_POST['os'];
 if($pk!='' && $pietro!='' && $osoby!=''){

include('polacz.php');

$zapytanie3="insert into hotele_pokoje(nr_pokoju,pietro,ludzie)
values('$pk','$pietro','$os');";
$wynik3=mysqli_query($connect,$zapytanie3);
 }



if($wynik3==true){
    header('location:index.html');
}else 
if($wynik3==false){
    echo" Nie dodano terminu  do bazy rezewacje. Błąd"; 
}

mysqli_close($connect);
?>