<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zapisane dane klientów nazwisko/miasto</title>
    <link rel="stylesheet" href="wypisywanie.css">
</head>
<body>
<?php
include('polacz.php');
        $zapytanie1 ="select nazwisko, id_miasto from hotele_klienci group by nazwisko;";
        $wynik=mysqli_query($connect,$zapytanie1);
        echo "<table border=1>";
        while($wiersz=mysqli_fetch_assoc($wynik)){
            echo "<td>".$wiersz["nazwisko"]."</td>";  
            echo "<td>".$wiersz["id_miasto"]."</td>"; 
        }
        echo "</table>";
        mysqli_close($connect); 
        ?>
</body>
</html>