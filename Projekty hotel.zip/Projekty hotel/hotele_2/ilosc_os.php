<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Określona ilość osób</title>
</head>
<body>
<?php
        include('polacz.php');
        $zapytanie1="select ludzie from hotele_pokoje;";
        $wynik=mysqli_query($connect,$zapytanie1);
        echo "<table border=1>";
        while($wiersz=mysqli_fetch_assoc($wynik)){
            echo "<td>".$wiersz["ludzie"]."</td>";  
        }
        echo "</table>";
        mysqli_close($connect); 
        ?>
</body>
</html>
