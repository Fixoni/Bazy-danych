<a href="index.html"></a>
<?php

$email=$_POST['email'];
$telefon=$_POST['tel'];
$nazwa=$_POST['nazwa'];
$addres=$_POST['adress'];
$strona=$_POST['str'];
$gwiazdki=$_POST['gw'];



//echo $nazwisko." ".$stanowisko." ".$data;

// $connect=@mysqli_connect('localhost','root','','kurs') or die('błąd połączenia bazy danych');
include('polacz.php');

$zapytanie2="insert into hotele(nazwa,adres,gwiazdki,telefon,email,www) 
values('$nazwa','$addres',''$gwiazdki,'$telefon','$email','$strona');";
$wynik2=mysqli_query($connect,$zapytanie2);
if($wynik2==true){
    echo " Dodano dane ".$nazwa."do bazy hotelów.";
    header('location:rejestracja.html');
}else{
    echo" Nie dodano danych ".$nazwa." do bazy hotelów. Błąd"; 
}
mysqli_close($connect);
?>