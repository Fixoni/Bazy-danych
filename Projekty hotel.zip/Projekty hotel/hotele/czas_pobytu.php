<a href="index.html"></a>
<?php

$zrealizowane=$_POST['wybor'];
$od=$_POST['od'];
$do=$_POST['do'];


//echo $nazwisko." ".$stanowisko." ".$data;

// $connect=@mysqli_connect('localhost','root','','kurs') or die('błąd połączenia bazy danych');
include('polacz.php');

$zapytanie3="insert into rezerwacje(data_start_rezerwacji, data_koniec_rezerwacji, zrealizowane)
values('$od','$do','$zrealizowane');";
$wynik3=mysqli_query($connect,$zapytanie3);
if($wynik3==true){
    echo " Dodano dane ".$od."/".$do."do bazy rezerwacje.";
    header('location:rejestracja.html');
}else{
    echo" Nie dodano terminu ".$od."/".$do." do bazy rezewacje. Błąd"; 
}
mysqli_close($connect);
?>