<a href="index.html"></a>
<?php

$imie=$_POST['im'];
$nazwisko=$_POST['naz'];
$adres=$_POST['adres'];



//echo $nazwisko." ".$stanowisko." ".$data;

// $connect=@mysqli_connect('localhost','root','','kurs') or die('błąd połączenia bazy danych');
include('polacz.php');

$zapytanie="insert into klienci(imie,nazwisko,adres,licznik) values('$imie','$nazwisko','$adres','$licznik');";
$wynik=mysqli_query($connect,$zapytanie);
    if($wynik==true){
        echo " Dodano klienta ".$nazwisko."do bazy klientów.";
        header('location:rejestracja.html');
    }else{
        echo" Nie dodano klienta ".$nazwisko." do bazy klientów. Błąd"; 
    }
mysqli_close($connect);
?>