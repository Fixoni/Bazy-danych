<?php

$login=$_POST['log'];
$pass=$_POST['pass'];
if($login=="admin" && $pass="123"){
    header('location:index.html');
}else{
    header('location:index.html');
    header('location://www.ruski.ru');
}
?>