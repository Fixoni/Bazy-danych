<?php
$connect=@mysqli_connect('localhost','root','','hotele') or die('błąd połączenia bazy danych');
?>